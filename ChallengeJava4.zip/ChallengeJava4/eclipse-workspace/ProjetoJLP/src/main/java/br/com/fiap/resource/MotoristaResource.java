package br.com.fiap.resource;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.beans.Motorista;
import br.com.fiap.bo.MotoristaBO;

@Path("/motorista")
public class MotoristaResource {

    private MotoristaBO motoristaBO = new MotoristaBO();

    // Selecionar
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Motorista> selecionarRs() throws ClassNotFoundException, SQLException {
        return (ArrayList<Motorista>) motoristaBO.selecionarBo();
    }

    // Inserir
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response inserirRs(Motorista motorista, @Context UriInfo uriInfo) throws ClassNotFoundException, SQLException {
        motoristaBO.inserirBo(motorista);

        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(motorista.getNome());
        return Response.created(builder.build()).build();
    }

    // Atualizar
    @PUT
    @Path("/{nome}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizarRs(Motorista motorista, @PathParam("nome") String nome) throws ClassNotFoundException, SQLException {
        motoristaBO.atualizarBo(motorista);

        return Response.ok().build();
    }

    // Deletar
    @DELETE
    @Path("/{nome}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deletarRs(@PathParam("nome") String nome) throws ClassNotFoundException, SQLException {
        motoristaBO.deletarBo(nome);
        return Response.ok().build();
    }
}
