package br.com.fiap.beans;

public class Motorista {

	private String nome;
	private String marca;
	private String carro;
	private int valorServico;
	private String manutencao;
	
	
	//construtor vazio
	public Motorista() {
		super();
	}


	//construtor vazio
	public Motorista(String nome, String marca, String carro, int valorServico, String manutencao) {
		super();
		this.nome = nome;
		this.marca = marca;
		this.carro = carro;
		this.valorServico = valorServico;
		this.manutencao = manutencao;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public String getCarro() {
		return carro;
	}


	public void setCarro(String carro) {
		this.carro = carro;
	}


	public int getValorServico() {
		return valorServico;
	}


	public void setValorServico(int valorServico) {
		this.valorServico = valorServico;
	}


	public String getManutencao() {
		return manutencao;
	}


	public void setManutencao(String manutencao) {
		this.manutencao = manutencao;
	}


	@Override
	public String toString() {
		return "Motorista [nome=" + nome + ", marca=" + marca + ", carro=" + carro + ", valorServico=" + valorServico
				+ ", manutencao=" + manutencao + "]";
	}
	
	
}
