package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Motorista;
import br.com.fiap.conexoes.ConexaoFactory;

public class dadosMotoristaDAO {
    private Connection conexao;

    public dadosMotoristaDAO() throws SQLException, ClassNotFoundException {
        this.conexao = new ConexaoFactory().conexao();
    }

    public void inserir(Motorista motorista) {
        String sql = "INSERT INTO T_MOTORISTA (nome, marca, carro, valorServico, manutencao) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, motorista.getNome());
            ps.setString(2, motorista.getMarca());
            ps.setString(3, motorista.getCarro());
            ps.setInt(4, motorista.getValorServico());
            ps.setString(5, motorista.getManutencao());
            ps.execute();
            System.out.println("Dados do motorista inseridos com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(String nome) {
        String sql = "DELETE FROM T_MOTORISTA WHERE nome = ?";
        try (PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, nome);
            ps.execute();
            System.out.println("Dados do motorista deletados com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void atualizar(Motorista motorista) {
        String sql = "UPDATE T_MOTORISTA SET marca = ?, carro = ?, valorServico = ?, manutencao = ? WHERE nome = ?";
        try (PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, motorista.getMarca());
            ps.setString(2, motorista.getCarro());
            ps.setInt(3, motorista.getValorServico());
            ps.setString(4, motorista.getManutencao());
            ps.setString(5, motorista.getNome());
            ps.executeUpdate();
            System.out.println("Dados do motorista atualizados com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Motorista> selecionar() {
        List<Motorista> motoristas = new ArrayList<>();
        String sql = "SELECT * FROM T_MOTORISTA";
        try (PreparedStatement ps = conexao.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Motorista motorista = new Motorista(
                    rs.getString("nome"),
                    rs.getString("marca"),
                    rs.getString("carro"),
                    rs.getInt("valorServico"),
                    rs.getString("manutencao")
                );
                motoristas.add(motorista);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return motoristas;
    }
}
