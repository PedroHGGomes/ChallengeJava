package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Motorista;
import br.com.fiap.dao.dadosMotoristaDAO;

public class TesteCadastro {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    static double real(String j) {
        return Double.parseDouble(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Motorista objMotorista = new Motorista();
        dadosMotoristaDAO dao = new dadosMotoristaDAO();

        
        objMotorista.setNome(texto("Nome do motorista"));
        objMotorista.setMarca(texto("Marca do carro"));
        objMotorista.setCarro(texto("Modelo do carro"));
        objMotorista.setValorServico(inteiro("Valor do serviço"));
        objMotorista.setManutencao(texto("Descrição da manutenção"));


        dao.inserir(objMotorista);
        System.out.println("Cadastro realizado com sucesso.");
    }
}
