package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Motorista;
import br.com.fiap.dao.dadosMotoristaDAO;

public class TesteDeletar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Motorista objMotorista = new Motorista();
        dadosMotoristaDAO dao = new dadosMotoristaDAO();


        objMotorista.setNome(texto("Digite o nome do motorista a ser deletado"));


        dao.deletar(objMotorista.getNome());
        System.out.println("Motorista deletado com sucesso.");
    }
}
