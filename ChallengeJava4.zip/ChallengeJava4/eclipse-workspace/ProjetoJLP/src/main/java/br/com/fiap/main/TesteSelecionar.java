package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Motorista;
import br.com.fiap.dao.dadosMotoristaDAO;

public class TesteSelecionar {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        dadosMotoristaDAO dao = new dadosMotoristaDAO();

        List<Motorista> listaMotorista = (ArrayList<Motorista>) dao.selecionar();

        if (listaMotorista != null) {
            for (Motorista motorista : listaMotorista) {
                System.out.println("Nome: " + motorista.getNome() + " | " +
                                   "Marca: " + motorista.getMarca() + " | " +
                                   "Carro: " + motorista.getCarro() + " | " +
                                   "Valor do Serviço: " + motorista.getValorServico() + " | " +
                                   "Manutenção: " + motorista.getManutencao());
            }
        }
    }
}
