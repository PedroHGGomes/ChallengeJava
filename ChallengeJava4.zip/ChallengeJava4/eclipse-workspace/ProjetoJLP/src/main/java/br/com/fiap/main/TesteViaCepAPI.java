package br.com.fiap.main;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.http.client.ClientProtocolException;

import br.com.fiap.beans.Endereco;
import br.com.fiap.service.ViaCepService;

public class TesteViaCepAPI {

	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	
	public static void main(String[] args) throws ClientProtocolException, IOException {


		ViaCepService viaCep = new ViaCepService();
		
		String cep = texto("Informe o cep do endereço para a busca");
		
		Endereco endereco = viaCep.getEndereco(cep);
		
		System.out.println("O RESGATE ESTA CHEGANDO NO SEGUITNE ENDERECO\n" +
                "CEP: " + endereco.getCep() +
                "\nCidade: " + endereco.getLocalidade() +
                "\nBairro: " + endereco.getBairro() +
                "\nLogradouro: " + endereco.getLogradouro());
}

}
