package br.com.fiap.bo;

import java.sql.SQLException;
import java.util.List;

import br.com.fiap.beans.Motorista;
import br.com.fiap.dao.dadosMotoristaDAO;

public class MotoristaBO {
    
    dadosMotoristaDAO motoristaDAO;

    // Selecionar
    public List<Motorista> selecionarBo() throws ClassNotFoundException, SQLException {
    	motoristaDAO = new dadosMotoristaDAO();
       
        
        return motoristaDAO.selecionar();
    }

    // Inserir
    public void inserirBo(Motorista motorista) throws ClassNotFoundException, SQLException {
    	motoristaDAO = new dadosMotoristaDAO();
    	
        
    	motoristaDAO.inserir(motorista);
    }

    // Atualizar
    public void atualizarBo(Motorista motorista) throws ClassNotFoundException, SQLException {
    	motoristaDAO = new dadosMotoristaDAO();

        
    	motoristaDAO.atualizar(motorista);
    }

    // Deletar
    public void deletarBo(String nome) throws ClassNotFoundException, SQLException {
    	motoristaDAO = new dadosMotoristaDAO();

        
    	motoristaDAO.deletar(nome);
    }
}
